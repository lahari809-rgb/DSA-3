@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist DocSim.jar (
  echo Building DocSim.jar ...
  if exist out rmdir /s /q out
  mkdir out
  dir /s /b src\main\java\*.java > sources.txt
  javac -encoding UTF-8 -d out @sources.txt
  if errorlevel 1 ( echo Build failed. Install a JDK 17+ and try again. & pause & exit /b 1 )
  xcopy /E /I /Q frontend out\frontend >nul
  jar cfe DocSim.jar texthack.api.Main -C out .
)
java -Dfile.encoding=UTF-8 -jar DocSim.jar
pause
